from crypt import methods
from email.mime import image
from flask import Flask, jsonify, send_file, render_template, request
import requests
import os
import io
import boto3
import base64

app = Flask(__name__)
colormap = 'twilight_shifted'
real = 0.36
imag = -0.09
height = 0.0024
dim = 512
iter = 128


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/all')
def all():
    return render_template('all.html')


@app.route('/moveUp', methods=['POST'])
def moveUp():
    global imag
    global height
    imag += 0.25 * height


@app.route('/moveDown', methods=['POST'])
def moveDown():
    global imag
    global height
    imag -= 0.25 * height


@app.route('/moveLeft', methods=['POST'])
def moveLeft():
    global real
    global height
    real -= 0.25 * height


@app.route('/moveRight', methods=['POST'])
def moveRight():
    global real
    global height
    real += 0.25 * height


@app.route('/zoomIn', methods=['POST'])
def zoomIn():
    global height
    height /= 1.4


@app.route('/zoomOut', methods=['POST'])
def zoomOut():
    global height
    height *= 1.4


@app.route('/smallerImage', methods=['POST'])
def smallerImage():
    global dim
    dim /= 1.25


@app.route('/largerImage', methods=['POST'])
def largerImage():
    global dim
    dim *= 1.25


@app.route('/moreIterations', methods=['POST'])
def moreIteration():
    global iter
    iter *= 2


@app.route('/lessIterations', methods=['POST'])
def lessIteration():
    global iter
    iter /= 2


@app.route('/changeColorMap', methods=['POST'])
def changeColorMap():
    global colormap
    print(request.get_json())
    colormap = request.get_json()['colormap']


@app.route('/mandelbrot', methods=['GET'])
def mandelbrot():
    response = requests.get(
        f'http://127.0.0.1:34000/mandelbrot/{colormap}/{real}:{imag}:{height}:{dim}:{iter}')
    if response.status_code != 200:
        return 404
    buffer = io.BytesIO(response.content)
    f = open('1.png', 'wb')
    f.write(response.content)
    f.close()
    upload_file(
        '1.png', 'my-bucket', f'/{colormap}/{real}:{imag}:{height}:{dim}:{iter}')
    return send_file(buffer, mimetype="image/png"), 200
    # return send_file(s3.Object('my-bucket', '{colormap}/{real}:{imag}:{height}:{dim}:{iter}').load()), 200


def upload_file(file_name, bucket, object_name=None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    # Upload the file
    s3_client = boto3.client('s3', aws_access_key_id='ROOTNAME',
                             aws_secret_access_key='CHANGEME123', endpoint_url="http://127.0.0.1:9000")
    response = s3_client.upload_file(file_name, bucket, object_name)
